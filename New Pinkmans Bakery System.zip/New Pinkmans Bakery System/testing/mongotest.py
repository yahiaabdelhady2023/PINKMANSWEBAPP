class X:
    def __init__(self):
        self.x = 10

    @property
    def x_change(self):
        return self.x
    

y=X()

y.x_change=2
print(y.x)