# flask_app/app/__init__.py

from flask import Flask
from .config import DevelopmentConfig
from .routes import *

def create_app(config_class=DevelopmentConfig):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Register routes here and assigning routes to functions
    app.add_url_rule('/', 'home', Home)
    app.add_url_rule('/Graphs','Graphs', Graphs)
    app.add_url_rule('/GetBranchesForReport','GetBranchesForReport',GetBranchesForReport , methods=['POST'])
    app.add_url_rule('/DisplayNewReport','DisplayNewReport',DisplayNewReport, methods=['POST'])
    app.add_url_rule('/Update_Plot_Graph','Update_Plot_Graph',Update_Plot_Graph,methods=['GET','POST'])
    app.add_url_rule('/plot.png','plot_png',plot_png,methods=['GET','POST'])
    app.add_url_rule('/Update_Branch_Specific_Items_Graph','Update_Branch_Specific_Items_Graph',Update_Branch_Specific_Items_Graph,methods=['GET','POST'])
    app.add_url_rule('/PasteriesBreakDown','PasteriesBreakDown',PasteriesBreakDown,methods=['GET','POST'])
    app.add_url_rule('/Login','Login',Login, methods=['POST','GET'])
    # app.add_url_rule('/Register','Register',Register,methods=['POST','GET'])
    app.add_url_rule('/SignOut','SignOut',SignOut ,methods=['GET','POST'])
    app.add_url_rule('/ValidateLogin','ValidateLogin',ValidateLogin,methods=['POST','GET'])
    return app
