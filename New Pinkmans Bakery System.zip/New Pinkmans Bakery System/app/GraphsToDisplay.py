import matplotlib
matplotlib.use('Agg')
#import libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from statsmodels.tsa.stattools import adfuller
import statsmodels.api as sm
from statsmodels.graphics.tsaplots import plot_acf, plot_pacf
import time
import datetime
import seaborn as sns
import io
import base64
from app.Models import *
from app.AggregateData import *
from datetime import date

# Get today's date
today = date.today()

# Format it as year-month-day
end_date = today.strftime("%Y-%m-%d")
start_date="2025-01-01"

database_handler_obj.Fetch_Missing_Date(start_date, end_date,"Order Date","WeeklyItemBreakDown",daily_labour_cost_report_obj,weekly_item_breakdown_report_obj)
dataframe=database_handler_obj.Fetch_Period(start_date,end_date,"Order Date","WeeklyItemBreakDown")
df = dataframe

# Explode the Orders column
df_exploded = df.explode('Orders', ignore_index=True)

# Convert the dictionaries in the Orders column to separate columns
Orders_df = pd.json_normalize(df_exploded['Orders'])

# Combine with parent-level columns
dataframe = pd.concat([df_exploded.drop(columns=['Orders']), Orders_df], axis=1)
DataFrame=dataframe
DataFrame=DataFrame[DataFrame['Gross Sale']!=0.0]
DataFrame.drop(['Lead Type','Tax Rate','Cost','Sales Type','Order ID','Order Time','Tax','Item Discount','Gross Sale'],axis=1,inplace=True)
DataFrame.isna().sum()

DataFrame['Order Date']=pd.to_datetime(DataFrame['Order Date'])
DataFrame['Sold Items']=1

# DataFrame=DataFrame[DataFrame['Venue']!='']
DataFrame = DataFrame[(DataFrame['Venue']!='Pinkmans - old market') & (DataFrame['Venue'] !='25A Old Market')]

all_branches=list(DataFrame['Venue'].unique())




def plot_per_branch(branch_name,item_name,start_period=None,end_period=None,y_axis_variable="Sold Items",return_ajax=False):
        if start_period is not None and end_period is not None:
                start_period = pd.to_datetime(start_period, format='%Y-%m-%d')
                end_period = pd.to_datetime(end_period, format='%Y-%m-%d')

        if branch_name != "All Branches":
                branch=DataFrame[DataFrame['Venue']==branch_name]
        else:
                branch=DataFrame

        branch=branch.groupby(['Order Date','PLU Name']).agg({'Net Sale': 'sum','Sold Items':'sum'}).reset_index()

        if item_name!="All Items":
                model=branch[branch['PLU Name']==item_name]
        else:
                model=branch.groupby('Order Date')[['Sold Items', 'Net Sale']].sum().reset_index()


        model=model.set_index('Order Date')
        if start_period is not None and end_period is not None:
                model=model[start_period:end_period]
        rolling_mean = model[y_axis_variable].rolling(window=7).mean()
        xdate=model.index
        ydate=model[y_axis_variable]
        plt.title(branch_name+" : "+item_name)
        plt.plot(xdate,ydate)
        plt.xticks(rotation=60)
        plt.tight_layout()
        plt.xlabel("Order Date",fontsize=16)
        plt.ylabel(y_axis_variable,fontsize=16)
        plt.plot(rolling_mean)
        plt.legend(['Original','Mean'])

        plt.tight_layout()

        output = io.BytesIO()
        plt.savefig(output, format='png')  # Save the current figure
        plt.close()  # Close the current plot to free memory
        output.seek(0)
        
        if return_ajax==True:
            return  base64.b64encode(output.getvalue()).decode('utf-8')
        else:
            return  output.getvalue()
        


def show_categories_break_down(branch_name,category_name="SOFT DRINKS",return_ajax=False):
    if branch_name != "All Branches":
        selected_branch=DataFrame[DataFrame['Venue']==branch_name]
    else:
        selected_branch=DataFrame
    if category_name != "All Categories":
        values=selected_branch[selected_branch['PLU Category']==category_name]['PLU Name'].value_counts()
    else:
        values=selected_branch['PLU Name'].value_counts()

    plt.bar(values.index[:10],values.values[:10])
    values.index
    plt.xticks(rotation=90)
    plt.tight_layout()
    plt.title(f"{branch_name}, Category Name : {category_name}")

    for i in range(len(values.index[:10])):
        plt.text(i,values.values[i],values.values[i], ha='center')

    plt.tight_layout()

    output = io.BytesIO()
    plt.savefig(output, format='png')  # Save the current figure
    plt.close()  # Close the current plot to free memory
    output.seek(0)
    
    if return_ajax==True:
        return  base64.b64encode(output.getvalue()).decode('utf-8')
    else:
        return  output.getvalue()


def get_season(month):
    if month in [12, 1, 2]:
        return 'Winter'
    elif month in [3, 4, 5]:
        return 'Spring'
    elif month in [6, 7, 8]:
        return 'Summer'
    elif month in [9, 10, 11]:
        return 'Autumn'

def show_trends_per_branch(branch_name,item_name,type_of_trend,return_ajax=False):

    if branch_name != "All Branches":
            branch=DataFrame[DataFrame['Venue']==branch_name]
    else:
            branch=DataFrame

    branch=branch.groupby(['Order Date','PLU Name']).agg({'Net Sale': 'sum','Sold Items':'sum'}).reset_index()

    if item_name!="All Items":
            branch=branch[branch['PLU Name']==item_name]
    else:
            branch=branch.groupby('Order Date')[['Sold Items', 'Net Sale']].sum().reset_index()

    
    branch=branch.set_index('Order Date')
    if type_of_trend=="Weekly":
        branch[type_of_trend] = branch.index.day_name()
        
    elif type_of_trend=="Monthly":
        branch[type_of_trend] = branch.index.month_name()
    else:
        branch[type_of_trend] = branch.index.month.map(get_season)
        print(branch[type_of_trend])

    trend_sales = branch.groupby(type_of_trend)[['Sold Items','Net Sale']].sum()
    # trend_sales.plot(kind='bar',stacked=True  ,color=['Green', 'lightblue'], alpha=0.8)

    trend_sales.plot(kind='bar')
    plt.title(f"{branch_name} Sold Items & Net Sale for whole period {item_name}")
    for i in range(len(trend_sales['Sold Items'].values)):
        plt.text(i,trend_sales['Sold Items'].values[i],trend_sales['Sold Items'].values[i], ha='right')

    trend_sales['Net Sale']=trend_sales['Net Sale'].round().apply(int)
    for i in range(len(trend_sales['Net Sale'].values)):
        plt.text(i,trend_sales['Net Sale'].values[i],trend_sales['Net Sale'].values[i], ha='left')

    plt.title(f"{branch_name} for whole period {item_name}")

    plt.tight_layout()

    output = io.BytesIO()
    plt.savefig(output, format='png')  # Save the current figure
    plt.close()  # Close the current plot to free memory
    output.seek(0)

    if return_ajax==True:
        return  base64.b64encode(output.getvalue()).decode('utf-8')
    else:
        return  output.getvalue()

def Get_All_Specific_Items(branch="All Branches"):
    if branch == "All Branches":
        return ["All Items"] + list(DataFrame['PLU Name'].unique())
    else:
        return ["All Items"] + list(DataFrame[DataFrame['Venue']==branch]['PLU Name'].unique())
    




def Get_All_Categories(branch="All Branches"):
    if branch == "All Branches":
        return ["All Categories"] + list(DataFrame['PLU Category'].unique())
    else:
        return ["All Categories"] + list(DataFrame[DataFrame['Venue']==branch]['PLU Category'].unique())
    

def Get_All_Branches():
     return   list(DataFrame['Venue'].unique()) + ["All Branches"]

KOBAS_EMAIL="mailer@kobas.co.uk"
IMAP_SERVER = 'imap.gmail.com'
IMAP_PORT = 993  # Port for SSL

#Gmail account credentials
EMAIL = 'facemessage78@gmail.com'
PASSWORD = 'kulu imye mavn cyny' 
connection_string="mongodb+srv://facemessage78:So02KSZ21vKUmwW8@cluster0.o1rwl.mongodb.net/"

file_processor_obj = FileProcessor()
email_handler_obj = EmailHandler(username=EMAIL,password=PASSWORD,server=IMAP_SERVER,port=IMAP_PORT)
email_handler_obj.ConnectGmail()
database_handler_obj = DatabaseHandler(database_name="PinkmanDB",connection_string=connection_string)
daily_labour_cost_report_obj=DailyLabourCostReport_EmailAPI(email_handler_obj,file_processor_obj,database_handler_obj)
weekly_item_breakdown_report_obj=WeeklyItemBreakDownReport_EmailAPI(email_handler_obj,file_processor_obj,database_handler_obj)