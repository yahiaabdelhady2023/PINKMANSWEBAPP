import pandas as pd
import imaplib
import email
from email.header import decode_header
import os
import openpyxl
import io

from pymongo import MongoClient
from datetime import datetime




class FileProcessor:
    @staticmethod
    def process_excel(file_like_object, date, columns_to_keep, date_column_name, old_format, new_format):
        dataframe = pd.read_excel(file_like_object, engine="openpyxl")
        dataframe.fillna(0, inplace=True)
        dataframe = dataframe[columns_to_keep]
        dataframe[date_column_name] = datetime.strptime(date, old_format).strftime(new_format)
        return dataframe

    @staticmethod
    def process_csv(file_like_object):
        dataframe = pd.read_csv(file_like_object)
        grouped_dataframe = (
            dataframe.groupby(["Order Date", "Venue"])
            .apply(lambda x: x.drop(["Order Date", "Venue"], axis=1).to_dict(orient="records"))
            .reset_index(name="Orders")
        )
        return grouped_dataframe


class EmailHandler:
    def __init__(self, email, password, server="imap.gmail.com", port=993):
        self.server = server
        self.port = port
        self.email = email
        self.password = password

    def connect_to_gmail(self, category="inbox"):
        try:
            mail = imaplib.IMAP4_SSL(self.server, self.port)
            mail.login(self.email, self.password)
            mail.select(category)
            return mail
        except Exception as e:
            raise ConnectionError(f"Failed to connect to Gmail: {e}")

    def fetch_attachment(self, mail, specific_date):
        try:
            status, all_emails = mail.search(None, f'ON "{specific_date}"')
            if all_emails == [b'']:
                raise FileNotFoundError(f"No Email Found for the specific date: {specific_date}")

            for email_id in all_emails[0].split():
                status, msg_data = mail.fetch(email_id, '(RFC822)')
                if status == "OK":
                    message = email.message_from_bytes(msg_data[0][1])
                    if message.is_multipart():
                        for part in message.walk():
                            if part.get("Content-Disposition") and "attachment" in part.get("Content-Disposition"):
                                return io.BytesIO(part.get_payload(decode=True))
            raise FileNotFoundError("No attachment found in the email.")
        except Exception as e:
            raise Exception(f"Error fetching attachment: {e}")



class DBOperations:
    def __init__(self, connection_string, database_name):
        self.client = MongoClient(connection_string)
        self.DB = self.client[database_name]
        self.data_dict = {}
        self.date_column = ""

    def get_collection(self, collection_name):
        return self.DB[collection_name]

    def set_data_dictionary(self, dataframe):
        self.data_dict = dataframe.to_dict(orient="records")

    def save_to_database(self, collection_name):
        collection = self.get_collection(collection_name)
        for single_dict in self.data_dict:
            collection.update_one(
                {self.date_column: single_dict[self.date_column], "Venue": single_dict["Venue"]},
                {"$set": single_dict},
                upsert=True
            )


class ReportsEmailAPI:
    def __init__(self, email_handler, db_operations, file_processor):
        self.email_handler = email_handler
        self.db_operations = db_operations
        self.file_processor = file_processor

    def get_daily_labour_cost(self, specific_date, folder, columns, date_column_name):
        mail = self.email_handler.connect_to_gmail(folder)
        file_like_object = self.email_handler.fetch_attachment(mail, specific_date)
        dataframe = self.file_processor.process_excel(
            file_like_object, 
            specific_date, 
            columns_to_keep=columns, 
            date_column_name=date_column_name, 
            old_format="%d-%b-%Y", 
            new_format="%Y-%m-%d"
        )
        self.db_operations.set_data_dictionary(dataframe)
        self.db_operations.date_column = date_column_name
        self.db_operations.save_to_database("DailyRevenue")


EMAIL = 'facemessage78@gmail.com'
PASSWORD = 'kulu imye mavn cyny' 
email_handler_obj = EmailHandler(EMAIL,PASSWORD)


db_operations_obj = DBOperations(
    connection_string="mongodb+srv://facemessage78:So02KSZ21vKUmwW8@cluster0.o1rwl.mongodb.net/",
    database_name="PinkmanDB"
)
file_processer_obj = FileProcessor()


r=ReportsEmailAPI(email_handler_obj,db_operations_obj,file_processer_obj)